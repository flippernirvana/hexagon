﻿using UnityEngine;
using System.Collections;
using UnityEngine.EventSystems;

public class MouseManager : MonoBehaviour {

	public Color color;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {

		Ray ray = Camera.main.ScreenPointToRay( Input.mousePosition );
		RaycastHit hitInfo;

		if( Physics.Raycast(ray, out hitInfo) ) {
			GameObject ourHitObject = hitInfo.transform.parent.gameObject;

			// So...what kind of object are we over?
			if(ourHitObject.GetComponent<Hex>() != null) {
				// Ah! We are over a hex!
				MouseOver_Hex(ourHitObject);
			}
		}
	}

	void MouseOver_Hex(GameObject ourHitObject) {
		
		if(Input.GetMouseButtonDown(0)) {
			SpriteRenderer sr = ourHitObject.GetComponentInChildren<SpriteRenderer>();
			GameObject map_go = GameObject.Find("Map");

			color = color == Color.red ? Color.blue : Color.red;
			if (sr.material.color == Color.white) {	
				sr.material.color = color;
				map_go.GetComponent<Map> ().addScore (color, 1);
				Hex hex = ourHitObject.GetComponent<Hex> ();
				hex.checkNeighbours (color);
			}
		}
	}
}
