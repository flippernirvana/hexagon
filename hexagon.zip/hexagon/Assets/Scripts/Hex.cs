﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class Hex : MonoBehaviour {

	// Our coordinates in the map array
	public float x;
	public float y;

	public void checkNeighbours(Color _color) {
		
		float[] xy = new float[14];
		float[] x3 = new float[3]; 
		float[] y3 = new float[3]; 	
		int markedCount = 0;
		//Debug.Log( "getNeighbours " + x + " " + y);

		x3 [0] = x;
		y3 [0] = y;
			
		xy [0] = x - 1.5f;
		xy [1] = y + 1f;
		xy [2] = x;
		xy [3] = y + 2f;
		xy [4] = x + 1.5f;
		xy [5] = y + 1f;
		xy [6] = x + 1.5f;
		xy [7] = y - 1f;
		xy [8] = x;
		xy [9] = y - 2f;
		xy [10] = x - 1.5f;
		xy [11] = y - 1f;
		xy [12] = xy [0];
		xy [13] = xy [1];
		for(int i = 0; i <= xy.GetLength(0)-1; i += 2) {
			GameObject neighbour = GameObject.Find("Hex_" + xy[i] + "_" + xy[i+1]);
			if (neighbour) {
				SpriteRenderer sr = neighbour.GetComponentInChildren<SpriteRenderer> ();
				//Debug.Log (i + " " + sr.material.color);	
				if (sr.material.color == _color) {
					markedCount++;
					x3 [2] = xy [i];
					y3 [2] = xy [i + 1];
				} else
					markedCount = 0;
			} else {
				//markedCount = 0;
				markedCount++;
				x3 [2] = xy [i];
				y3 [2] = xy [i + 1];
			}
			if (markedCount == 2) { 
				this.getTargetHex (x3, y3, _color);
				markedCount--;
			}
			x3 [1] = xy [i];
			y3 [1] = xy [i + 1];
		}
	}  

	private void getTargetHex(float[] _x3, float[] _y3, Color _color)
	{
		GameObject map_go = GameObject.Find("Map");
		GameObject targetHex = GameObject.Find("Hex_" + (_x3.Max() - 0.5f) + "_" + (_y3.Max() - 1f));

		if (!targetHex) {
			targetHex = GameObject.Find ("Hex_" + (_x3.Max () - 1f) + "_" + (_y3.Max () - 1f));
			if (targetHex) {
				SpriteRenderer sr = targetHex.GetComponentInChildren<SpriteRenderer> ();
				if(sr.material.color != Color.white)
					map_go.GetComponent<Map> ().addScore (sr.material.color, 1, true);
				map_go.GetComponent<Map> ().addScore (_color, 1);
				sr.material.color = _color;	
			}
		} else {
			SpriteRenderer sr = targetHex.GetComponentInChildren<SpriteRenderer> ();
			if(sr.material.color != Color.white)
				map_go.GetComponent<Map> ().addScore (sr.material.color, 1, true);
			map_go.GetComponent<Map> ().addScore (_color, 1);
			sr.material.color = _color;	
		}
	}
}
