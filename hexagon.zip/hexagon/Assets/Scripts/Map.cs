﻿using UnityEngine;
using System.Collections;

public class Map : MonoBehaviour {

	public GameObject hexPrefab;
	public int hexPerEdge = 10;
	public int redScore = 0;
	public int blueScore = 0;

	float yOffset = 0.866f;

	// Use this for initialization
	void Start () 
	{
		bool half = false;
		int y = 0;
		float x = 0f;
		float firstX = 0;
		int xPerY = hexPerEdge;
		float nextX = ((hexPerEdge * 2 - 1) / 2 - hexPerEdge / 2) + 0.5f; ;
		float lastX = nextX;
		int countX = 0;

		do {
			do 
			{
				GameObject hex_go = (GameObject)Instantiate (hexPrefab, new Vector3 (x, y * yOffset, 0), Quaternion.identity);
				hex_go.name = "Hex_" + nextX + "_" + y;
				hex_go.GetComponent<Hex>().x = nextX;
				hex_go.GetComponent<Hex>().y = y;
				hex_go.transform.SetParent (this.transform);
				x++;
				countX++;
				nextX++;
			} while(countX != xPerY);
			countX = 0;
			if(y == hexPerEdge -1)
				half = true;
			xPerY = half? xPerY - 1: xPerY + 1;
			firstX = half? firstX + 0.5f: firstX - 0.5f;
			x = firstX;
			y++;
			nextX = half? lastX + 0.5f: lastX - 0.5f;
			lastX = nextX;
		} while(y != 2 * hexPerEdge - 1);
	}

	public void addScore(Color _color, int _i, bool _minus = false )
	{
		TextMesh textMesh;

		if (_color == Color.red) {
			redScore += _minus? -_i: _i;
			textMesh = GameObject.Find ("PlayerRed").GetComponentInChildren<TextMesh> ();
			textMesh.text = (redScore).ToString ();
		} else {
			blueScore += _minus? -_i: _i;
			textMesh = GameObject.Find ("PlayerBlue").GetComponentInChildren<TextMesh> ();
			textMesh.text = (blueScore).ToString ();
		}
	}

	void Update () {

	}
}
